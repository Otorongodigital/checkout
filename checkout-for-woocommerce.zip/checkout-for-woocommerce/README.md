# Checkout For Woocommerce

### Development installation instructions

* Create .env file with CFW_DEV_MODE=true to enable development mode (source maps and non minified files)
* More instructions go here

### Normal use installation instructions

* Normal use instructions go here