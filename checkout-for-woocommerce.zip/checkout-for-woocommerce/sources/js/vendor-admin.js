require( 'script-loader!jquery-validation/dist/jquery.validate.js' );
