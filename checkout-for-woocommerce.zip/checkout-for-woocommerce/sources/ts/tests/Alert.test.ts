import { Alert, AlertInfo } from '../frontend/Components/Alert';

describe( 'Alert.ts', () => {
    const container = document.createElement( 'div' );
    container.id = 'cfw-alert-container';;
    document.body.appendChild( container );

    const errorInfo = <AlertInfo>{ type: 'error', message: 'error message', cssClass: 'error-class' };
    const noticeInfo = <AlertInfo>{ type: 'notice', message: 'notice message', cssClass: 'notice-class' };
    const successInfo = <AlertInfo>{ type: 'success', message: 'success message', cssClass: 'success-class' };

    let eventCounter = 0;

    window.addEventListener( 'cfw-add-alert-event', () => { eventCounter += 1; } );

    const errorAlert   = new Alert( container, errorInfo );
    const noticeAlert  = new Alert( container, noticeInfo );
    const successAlert = new Alert( container, successInfo );

    errorAlert.addAlert();
    noticeAlert.addAlert();
    successAlert.addAlert();

    test( 'addAlert', () => {
        const errorAlertjQuery = jQuery( container ).find( `.${errorInfo.cssClass}` );
        expect( errorAlertjQuery.length ).toBe( 1 );
        expect( errorAlertjQuery.hasClass( errorInfo.cssClass ) ).toBeTruthy();
        expect( errorAlertjQuery.hasClass( 'cfw-alert' ) ).toBeTruthy();
        expect( errorAlertjQuery.find( '.message' ).length ).toBe( 1 );
        expect( errorAlertjQuery.find( '.message' ).html() ).toBe( errorInfo.message );


        const noticeAlertjQuery = jQuery( container ).find( `.${noticeInfo.cssClass}` );
        expect( noticeAlertjQuery.length ).toBe( 1 );
        expect( noticeAlertjQuery.hasClass( noticeInfo.cssClass ) ).toBeTruthy();
        expect( noticeAlertjQuery.hasClass( 'cfw-alert' ) ).toBeTruthy();
        expect( noticeAlertjQuery.find( '.message' ).length ).toBe( 1 );
        expect( noticeAlertjQuery.find( '.message' ).html() ).toBe( noticeInfo.message );

        const successAlertjQuery = jQuery( container ).find( `.${successInfo.cssClass}` );
        expect( successAlertjQuery.length ).toBe( 1 );
        expect( successAlertjQuery.hasClass( successInfo.cssClass ) ).toBeTruthy();
        expect( successAlertjQuery.hasClass( 'cfw-alert' ) ).toBeTruthy();
        expect( successAlertjQuery.find( '.message' ).length ).toBe( 1 );
        expect( successAlertjQuery.find( '.message' ).html() ).toBe( successInfo.message );
    } );

    test( 'removeAlerts', () => {
        Alert.removeAlerts( jQuery( container ) );

        expect( container.children.length ).toBe( 0 );
    } );

    test( 'cfw-add-alert-event', () => {
        expect( eventCounter ).toBe( 3 );
    } );
} );
