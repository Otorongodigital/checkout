interface JQuery {
    parsley: any;
}
