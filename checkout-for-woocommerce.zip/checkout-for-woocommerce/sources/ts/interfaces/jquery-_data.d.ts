interface JQueryStatic {
    _data: any;
}
