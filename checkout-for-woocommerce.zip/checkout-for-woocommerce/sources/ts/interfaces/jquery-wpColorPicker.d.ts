interface JQuery {
    wpColorPicker: any;
}
