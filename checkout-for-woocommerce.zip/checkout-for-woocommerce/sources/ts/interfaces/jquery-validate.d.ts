interface JQuery {
    validate: any;
}
