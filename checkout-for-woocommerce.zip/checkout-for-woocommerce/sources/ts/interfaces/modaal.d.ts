interface JQuery {
    modaal: any;
}
