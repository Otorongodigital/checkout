<?php

namespace Objectiv\Plugins\Checkout;

class AdminFiltersController {
	public function __construct() {

	}

	public function init() {}
}
