<?php

namespace Objectiv\Plugins\Checkout\Interfaces;

interface RunsOnPluginActivationInterface {
	public function run_on_plugin_activation();
}
