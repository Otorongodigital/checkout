<?php

namespace Objectiv\Plugins\Checkout\Interfaces;

interface RunsOnPluginDeactivationInterface {
	public function run_on_plugin_deactivation();
}
