<?php
/**
 * For Copify, the footer is defined in content.php for layout purposes
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
