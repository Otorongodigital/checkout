export class Theme {
    constructor() {

    }
}