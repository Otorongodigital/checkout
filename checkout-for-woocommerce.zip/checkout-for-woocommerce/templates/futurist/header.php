<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<header id="cfw-header" class="container-fluid">
	<div class="row">
		<div class="col-12">
			<div id="cfw-logo-container">
				<?php cfw_logo(); ?>
			</div>
		</div>
	</div>
</header>
