<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<header id="cfw-header">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div id="cfw-logo-container">
					<?php cfw_logo(); ?>
				</div>
			</div>
		</div>
	</div>
</header>
